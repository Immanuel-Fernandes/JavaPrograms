import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class UserDashboard extends JFrame {

    private JTextArea cartTextArea;
    private double totalAmount;
    private JLabel totalLabel;
    private BillingDashboard billingDashboard;
    private List<Product> productList;
    private String username;

    public UserDashboard(String username) {
        this.username = username;
        setTitle("Soil Enthusiast - User Dashboard" );

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        productList = new ArrayList<>();

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        add(mainPanel);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.LIGHT_GRAY);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JLabel titleLabel = new JLabel("Welcome,  " + username);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel);

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Create and add the categories combo box
        JPanel categoryPanel = new JPanel();
        JLabel categoryLabel = new JLabel("Category:");
        JComboBox<String> categoryComboBox = new JComboBox<>();
        categoryComboBox.addItem("Compostable Products");
        categoryComboBox.addItem("Eco-Friendly Tools");
        categoryComboBox.addItem("Biodegradable Bags");
        categoryComboBox.addItem("Sustainable Stationary");
        categoryComboBox.addItem("Recycled Materials");
        categoryComboBox.addItem("Compost");
        categoryPanel.add(categoryLabel);
        categoryPanel.add(categoryComboBox);
        contentPanel.add(categoryPanel, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane();
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel productsPanel = new JPanel(new GridLayout(0, 2, 10, 10));
       
        productsPanel.setBorder(BorderFactory.createTitledBorder("Eco-Friendly Products"));
        scrollPane.setViewportView(productsPanel);


        productList.add(new Product("Compostable Cutlery Set", "Compostable_Cutlery_Set.jpg", "Rs. 100", 100, "Compostable Products"));
        productList.add(new Product("Bamboo Tableware Set", "Bamboo_Tableware_Set.jpg", "Rs. 120", 120, "Compostable Products"));

        productList.add(new Product("Garden Tools", "Garden_Tools.jpg", "Rs. 200", 200, "Eco-Friendly Tools"));
        productList.add(new Product("Energy-Efficient LED Bulbs", "Energy-Efficient_LED_Bulbs.jpg", "Rs. 30", 30, "Eco-Friendly Tools"));

        productList.add(new Product("Biodegradable Garbage Bags", "Biodegradable_Garbage_Bags.jpg", "Rs. 50", 50, "Biodegradable Bags"));
        productList.add(new Product("Reusable Cloth Shopping Bags", "Reusable_Cloth_Shopping_Bags.jpg", "Rs. 20", 20, "Biodegradable Bags"));

        productList.add(new Product("Recycled Paper Notebook", "Recycled_Paper_Notebook.jpg", "Rs. 150", 150, "Sustainable Stationary"));
        productList.add(new Product("Recycled Printing Paper", "Recycled_Printing_Paper.jpg", "Rs. 250", 250, "Sustainable Stationary"));
        productList.add(new Product("Sustainable Stationary", "Sustainable_Stationary.jpg", "Rs. 1000", 1000, "Sustainable Stationary"));
        

        productList.add(new Product("Recycled PET Bottles Backpack", "Recycled_PET_Bottles_Backpack.jpg", "Rs. 180", 180, "Recycled Materials"));

        productList.add(new Product("Vegetable Compost", "vegetable_compost.jpg", "Rs. 50", 50, "Compost"));
        productList.add(new Product("Yard Waste Compost", "yard_waste_compost.jpg", "Rs. 40", 40, "Compost"));        
        productList.add(new Product("Coffee Grounds Compost", "coffee_grounds_compost.jpg", "Rs. 30", 30, "Compost"));
        productList.add(new Product("Vermicompost", "vermicompost.jpg", "Rs. 70", 70, "Compost"));        
        productList.add(new Product("Mushroom Compost", "mushroom_compost.jpg", "Rs. 65", 65, "Compost"));




        // Add more eco-friendly products as needed

        updateProductPanel(productsPanel, "All");

        JPanel leftPanel = new JPanel(new BorderLayout());
        contentPanel.add(leftPanel, BorderLayout.WEST);

        JPanel cartPanel = new JPanel(new BorderLayout());
        cartPanel.setPreferredSize(new Dimension(200, 400));
        cartPanel.setBorder(BorderFactory.createTitledBorder("Cart"));
        leftPanel.add(cartPanel, BorderLayout.CENTER);

        cartTextArea = new JTextArea();
        cartTextArea.setEditable(false);
        JScrollPane cartScrollPane = new JScrollPane(cartTextArea);
        cartPanel.add(cartScrollPane, BorderLayout.CENTER);

        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalLabel = new JLabel("Total Amount: Rs. 0.00");
        totalPanel.add(totalLabel);
        cartPanel.add(totalPanel, BorderLayout.SOUTH);


        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton resetButton = new JButton("Reset");
        JPanel resetPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.add(resetPanel, BorderLayout.WEST);
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetCart();
            }
        });
        resetPanel.add(resetButton);
        
        JButton checkoutButton = new JButton("Checkout");
        checkoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	if (totalAmount == 0.0) {
                    JOptionPane.showMessageDialog(UserDashboard.this, "Please select products before checkout.");
            	}else {
                JOptionPane.showMessageDialog(UserDashboard.this, "Checkout complete!");
                showBillingDashboard();
            }
            }
        });
        
        bottomPanel.add(checkoutButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(username+" Logged Out");
                dispose(); // Dispose the current frame
                new LoginFrame().setVisible(true); // Open the LoginFrame
            }
        });
        bottomPanel.add(logoutButton);

        JButton compostCalculatorButton = new JButton("Compost Calculator");
        compostCalculatorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CompostCalculatorFrame compostCalculatorFrame = new CompostCalculatorFrame("0", "0", "0",username);
                compostCalculatorFrame.setVisible(true);
            }
        });
        bottomPanel.add(compostCalculatorButton);


        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        categoryComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCategory = (String) categoryComboBox.getSelectedItem();
                updateProductPanel(productsPanel, selectedCategory);
            }
        });


    }

    private void updateProductPanel(JPanel productsPanel, String selectedCategory) {
        productsPanel.removeAll();

        // Iterate over the products and add only those matching the selected category
        for (Product product : productList) {
            if (selectedCategory.equals("All") || product.getCategory().equals(selectedCategory)) {
                addProductPanel(productsPanel, product);
            }
        }

        // Refresh the panel
        productsPanel.revalidate();
        productsPanel.repaint();
    }
    public void resetCart() {
        cartTextArea.setText("");
        totalAmount = 0.0;
        totalLabel.setText("Total Amount: Rs. 0.00");
    }
    private void addProductPanel(JPanel productsPanel, Product product) {
        try {
            Image productImage = ImageIO.read(new File(product.getImagePath()));
            Image scaledProductImage = productImage.getScaledInstance(150, 150, Image.SCALE_SMOOTH);

            JPanel productPanel = new JPanel(new GridBagLayout());
            productPanel.setPreferredSize(new Dimension(200, 250));
            productPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            JLabel imageLabel = new JLabel(new ImageIcon(scaledProductImage));
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.BOTH;
            gbc.anchor = GridBagConstraints.CENTER;
            gbc.insets = new Insets(0, 0, 10, 0);
            productPanel.add(imageLabel, gbc);

            JLabel nameLabel = new JLabel(product.getProductName());
            gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.CENTER;
            gbc.insets = new Insets(0, 0, 5, 0);
            productPanel.add(nameLabel, gbc);

            JLabel priceLabel = new JLabel(product.getPrice());
            gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.CENTER;
            gbc.insets = new Insets(0, 0, 5, 0);
            productPanel.add(priceLabel, gbc);

            JButton addToCartButton = new JButton("Add to Cart");
            gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.CENTER;
            productPanel.add(addToCartButton, gbc);

            addToCartButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String cartItem = product.getProductName() + " - " + product.getPrice();
                    cartTextArea.append(cartItem + "\n");
                    totalAmount += product.getAmount();
                    totalLabel.setText(String.format("Total Amount: Rs. %.2f", totalAmount));
                }
            });

            JButton removeButton = new JButton("Remove");
            removeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String cartItem = product.getProductName() + " - " + product.getPrice();
                    String cartText = cartTextArea.getText();
                    int index = cartText.indexOf(cartItem);

                    // Check if the cart item exists
                    if (index >= 0) {
                        // Find the first occurrence of the cart item and remove it
                        cartText = cartText.substring(0, index) + cartText.substring(index + cartItem.length());
                        cartTextArea.setText(cartText);

                        // Check if the total amount is greater than zero before performing the decrease
                        if (totalAmount > 0) {
                            totalAmount -= product.getAmount();
                            totalLabel.setText(String.format("Total Amount: Rs. %.2f", totalAmount));
                        }
                    }
                }
            });
            JPanel buttonPanel = new JPanel(new BorderLayout());
            buttonPanel.add(removeButton, BorderLayout.WEST);
            buttonPanel.add(addToCartButton, BorderLayout.EAST);
            gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.anchor = GridBagConstraints.CENTER;
            productPanel.add(buttonPanel, gbc);

            productsPanel.add(productPanel);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showBillingDashboard() {
        BillingDashboard billingDashboard = new BillingDashboard(cartTextArea.getText(), totalAmount, username);
        billingDashboard.setVisible(true);
    }
    
    public class Product {
        private String productName;
        private String imagePath;
        private String price;
        private double amount;
        private String category;

        public Product(String productName, String imagePath, String price, double amount, String category) {
            this.productName = productName;
            this.imagePath = imagePath;
            this.price = price;
            this.amount = amount;
            this.category = category;
        }

        public String getProductName() {
            return productName;
        }

        public String getImagePath() {
            return imagePath;
        }

        public String getPrice() {
            return price;
        }

        public double getAmount() {
            return amount;
        }

        public String getCategory() {
            return category;
        }
    }
    public static void main(String[] args) {
        UserDashboard userDashboard = new UserDashboard("Soil");
        userDashboard.setVisible(true);
    }
}