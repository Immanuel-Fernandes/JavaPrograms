import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CompostCalculatorFrame extends JFrame {

    private JLabel projectTypeLabel;
    private JComboBox<String> projectTypeComboBox;
    private JLabel lengthLabel;
    private JTextField lengthField;
    private JLabel widthLabel;
    private JTextField widthField;
    private JLabel depthLabel;
    private JTextField depthField;
    private JButton calculateButton;
    private JTextArea resultArea;
    private String username;

    double compostNeeded = 0;

    public CompostCalculatorFrame(String length, String width, String depth,String username) {
        setTitle("Compost Calculator");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(6, 10, 50, 5));
        this.username = username;

        projectTypeLabel = new JLabel("Project Type:");
        add(projectTypeLabel);

        projectTypeComboBox = new JComboBox<>(new String[]{"New Lawns", "Established Lawns", "Gardens", "Raised Beds", "Trees and Shrubs"});
        add(projectTypeComboBox);

        

        lengthLabel = new JLabel("Length (ft):");
        add(lengthLabel);
        lengthField = new JTextField(10);
        add(lengthField);

        widthLabel = new JLabel("Width (ft):");
        add(widthLabel);
        widthField = new JTextField(10);
        add(widthField);

        depthLabel = new JLabel("Compost Depth (in):");
        add(depthLabel);
        depthField = new JTextField(10);
        add(depthField);

        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateCompost();
            }
        });
        
        add(calculateButton);

        resultArea = new JTextArea(1, 5);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        add(scrollPane);

        

        // Set default values based on the inputs from the previous frame
        lengthField.setText(length);
        widthField.setText(width);
        depthField.setText(depth);

        // Automatically calculate compost
        calculateCompost();

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }


    private void calculateCompost() {
        int projectTypeIndex = projectTypeComboBox.getSelectedIndex();
        int length = Integer.parseInt(lengthField.getText());
        int width = Integer.parseInt(widthField.getText());
        int depth = Integer.parseInt(depthField.getText());

        

        switch (projectTypeIndex) {
            case 0:
                compostNeeded = calculateCompostForNewLawns(length, width, depth);
                break;
            case 1:
                compostNeeded = calculateCompostForEstablishedLawns(length, width, depth);
                break;
            case 2:
                compostNeeded = calculateCompostForGardens(length, width, depth);
                break;
            case 3:
                compostNeeded = calculateCompostForRaisedBeds(length, width, depth);
                break;
            case 4:
                compostNeeded = calculateCompostForTreesAndShrubs(length, width, depth);
                break;
        }

        // Convert cubic yards to kilograms (1 cubic yard = 764.554858 kg)
        //double kilogramsRequired = compostNeeded * 764.554858;
        //resultArea.setText("You will need:\n" + kilogramsRequired + " kilograms of compost");

        resultArea.setText("You will need:\n" + compostNeeded + " cubic yard of compost");

        if (compostNeeded>0)
        {
            saveToDatabase(username);
        }
    }

    private double calculateCompostForNewLawns(int length, int width, int depth) {
        return (length * width * depth) / 324.0;
    }

    private double calculateCompostForEstablishedLawns(int length, int width, int depth) {
        return (length * width * depth) / 648.0;
    }

    private double calculateCompostForGardens(int length, int width, int depth) {
        return (length * width * depth) / 162.0;
    }

    private double calculateCompostForRaisedBeds(int length, int width, int depth) {
        return (length * width * depth) / 324.0;
    }

    private double calculateCompostForTreesAndShrubs(int length, int width, int depth) {
        return (length * width * depth) / 648.0;
    }

    private void saveToDatabase(String Username) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/soil_enthusiast", "root", "root")) {
            String sql = "INSERT INTO CompostCalculated (username, length, width, depth, weight) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Get values from the input fields
            String username = Username; 
            int length = Integer.parseInt(lengthField.getText());
            int width = Integer.parseInt(widthField.getText());
            int depth = Integer.parseInt(depthField.getText());
           // double compostNeeded = calculateCompost();

            // Calculate weight in kg (assuming 1 cubic yard = 764.554858 kg)
            //double weight = compostNeeded * 764.554858;
            double weight = compostNeeded;

            pstmt.setString(1, username);
            pstmt.setInt(2, length);
            pstmt.setInt(3, width);
            pstmt.setInt(4, depth);
            pstmt.setDouble(5, weight);
            pstmt.executeUpdate();

            System.out.println("Calculation Data saved to database successfully!");
        } catch (SQLException e) {
            System.out.println("Error saving data to database: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
