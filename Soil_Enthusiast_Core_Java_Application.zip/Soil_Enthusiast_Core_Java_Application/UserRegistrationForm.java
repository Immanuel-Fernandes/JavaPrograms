import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserRegistrationForm extends JFrame implements ActionListener {

    private JTextField usernameField;
    private JTextField pincodeField;
    private JTextField MobileNoField;
    private JTextField AddressField;
    private JTextField DateField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton registerButton;
    private JButton loginButton;

    public UserRegistrationForm() {
        setTitle("User Registration Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(8, 2));

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();

        JLabel lastNameLabel = new JLabel("Pincode:");
        pincodeField = new JTextField();

        JLabel MobileNoLabel = new JLabel("Mobile number:");
        MobileNoField = new JTextField();

        JLabel addressLabel = new JLabel("Address:");
        AddressField = new JTextField();

        JLabel dateLabel = new JLabel("DOB:");
        DateField = new JTextField();

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        registerButton = new JButton("Register");
        registerButton.addActionListener(this);

        loginButton = new JButton("Login"); // Adding a login button
        loginButton.addActionListener(this);

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(emailLabel);
        add(emailField);
        add(MobileNoLabel);
        add(MobileNoField);
        add(dateLabel);
        add(DateField);
        add(addressLabel);
        add(AddressField);
        add(lastNameLabel);
        add(pincodeField);

        add(registerButton);
        add(loginButton); // Adding the login button

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UserRegistrationForm());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(registerButton)) {
            String username = usernameField.getText();
            String pin = pincodeField.getText();
            int pincode = Integer.parseInt(pin);
            String mobile = MobileNoField.getText();
            int mobileNo;
            try {
                mobileNo = Integer.parseInt(mobile);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid mobile number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String address = AddressField.getText();
            String dob = DateField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // Validate inputs
            if (!isValidEmail(email)) {
                JOptionPane.showMessageDialog(this, "Invalid email address.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Insert into register table
            try {
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Soil_Enthusiast", "root", "root");
                PreparedStatement ps = con.prepareStatement("INSERT INTO register VALUES (?,?,?,?,?,?,?,?)");
                ps.setInt(1, 0); // Assuming ID is auto-incremented
                ps.setString(2, username);
                ps.setString(3, password);
                ps.setString(4, email);
                ps.setInt(5, mobileNo);
                ps.setString(6, dob);
                ps.setString(7, address);
                ps.setInt(8, pincode);

                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "User registered successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("User registered successfully!");

                // Insert into login table
                ps = con.prepareStatement("INSERT INTO login (username, password) VALUES (?, ?)");
                ps.setString(1, username);
                ps.setString(2, password);
                ps.executeUpdate();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error registering user: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }

            // Clear the form fields after registration
            usernameField.setText("");
            pincodeField.setText("");
            MobileNoField.setText("");
            AddressField.setText("");
            DateField.setText("");
            emailField.setText("");
            passwordField.setText("");
        }
        else if (e.getSource().equals(loginButton)) {
            // Handle login button click, for example, open the login frame
            new LoginFrame();
            this.dispose(); // Dispose the registration frame
        }
    } 
    

    private boolean isValidEmail(String email) {
        // Basic email validation
        return email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
    }
}
