import java.io.IOException;

public class SoilEnthusiast {

    public SoilEnthusiast() {
        // Run DatabaseSetup command
        runCommand("cmd", "/c", "javac", "DatabaseSetup.java");
        runCommand("cmd", "/c", "java", "DatabaseSetup");

        // Run TableSetup command
        runCommand("cmd", "/c", "javac", "TableSetup.java");
        runCommand("cmd", "/c", "java", "TableSetup");

        // Run UserRegistrationForm command
        runCommand("cmd", "/c", "javac", "UserRegistrationForm.java");
        runCommand("cmd", "/c", "java", "UserRegistrationForm");
    }

    public void runCommand(String... command) {
        ProcessBuilder pb = new ProcessBuilder(command);
        try {
            Process process = pb.inheritIO().start();
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SoilEnthusiast soilEnthusiast = new SoilEnthusiast();
    }
}
