import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatabaseSetup {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    private static final Logger logger = Logger.getLogger(DatabaseSetup.class.getName());

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            try (PreparedStatement ps = connection.prepareStatement("CREATE DATABASE IF NOT EXISTS soil_enthusiast")) {
                ps.executeUpdate();
            }
            System.out.println("Database setup completed successfully.");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database setup error: " + e.getMessage(), e);
        }
    }
}
