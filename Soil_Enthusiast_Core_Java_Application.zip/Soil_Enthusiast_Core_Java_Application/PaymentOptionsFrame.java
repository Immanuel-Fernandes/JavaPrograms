import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PaymentOptionsFrame extends JFrame {
    private JTextField addressTextField;
    private JLabel addressLabel;
    private String username;
    private JPanel buttonPanel;

    public PaymentOptionsFrame(String products, double totalAmount, String username) {
        setTitle("Payment Options");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 400);
        setLocationRelativeTo(null);
        this.username = username;

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        add(mainPanel);

        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.LIGHT_GRAY);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JLabel titleLabel = new JLabel("Payment Options");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(titleLabel);

        JPanel optionsPanel = new JPanel(new GridBagLayout());
        optionsPanel.setBorder(BorderFactory.createTitledBorder("Payment Options"));
        mainPanel.add(optionsPanel, BorderLayout.CENTER);

        JRadioButton option1RadioButton = new JRadioButton("UPI");
        JRadioButton option2RadioButton = new JRadioButton("Cash on Delivery");
        JRadioButton option3RadioButton = new JRadioButton("Net Banking");

        ButtonGroup paymentOptionsGroup = new ButtonGroup();
        paymentOptionsGroup.add(option1RadioButton);
        paymentOptionsGroup.add(option2RadioButton);
        paymentOptionsGroup.add(option3RadioButton);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        optionsPanel.add(option1RadioButton, gbc);

        gbc.gridy++;
        optionsPanel.add(option2RadioButton, gbc);

        gbc.gridy++;
        optionsPanel.add(option3RadioButton, gbc);

        addressTextField = new JTextField();
        addressTextField.setPreferredSize(new Dimension(300, 50)); // Set preferred size
        addressLabel = new JLabel("Address");
        gbc.gridy++;
        optionsPanel.add(addressLabel, gbc);

        gbc.gridy++;
        optionsPanel.add(addressTextField, gbc);

        JButton proceedButton = new JButton("Proceed");
        proceedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedOption = "";
                if (option1RadioButton.isSelected()) {
                    selectedOption = "UPI";
                } else if (option2RadioButton.isSelected()) {
                    selectedOption = "Cash on Delivery";
                } else if (option3RadioButton.isSelected()) {
                    selectedOption = "Net Banking";
                } else {
                    JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Please select a payment option.");
                    return;
                }

                String address = addressTextField.getText();
                if (address.isEmpty()) {
                    JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Please enter an address.");
                    return;
                }

                // Save order details to database
                saveOrderDetails(username, products, totalAmount, selectedOption, address);

                JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Selected Option: " + selectedOption);
                JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Payment Successful\nSave the Receipt");
                generateReceipt(products, totalAmount, address);
                JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Receipt Downloaded\nVisit again");
                disposeAllAndOpenHome();
            }
        });
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(proceedButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void saveOrderDetails(String username, String products, double totalAmount, String paymentMode, String address) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/soil_enthusiast";
        String dbUsername = "root";
        String dbPassword = "root";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword)) {
            String sql = "INSERT INTO order_details (username, product_details, total_amount, payment_mode, address) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                statement.setString(2, products);
                statement.setDouble(3, totalAmount);
                statement.setString(4, paymentMode);
                statement.setString(5, address);

                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Order details saved successfully.");
                } else {
                    JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Failed to save order details.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(PaymentOptionsFrame.this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void generateReceipt(String products, double totalAmount, String address) {
        JFileChooser fileChooser = new JFileChooser();
        int userChoice = fileChooser.showSaveDialog(this);
        if (userChoice == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getPath();
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
                writer.write("Receipt\n\n");
                writer.write("Products: \n");
                writer.write(products);
                writer.write("\n\n");
                writer.write("Total Amount: ₹" + totalAmount);
                writer.write("\n\n");
                writer.write("Address: " + address);
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void disposeAllAndOpenHome() {
        Window[] windows = Window.getWindows();
        for (Window window : windows) {
            window.dispose();
        }
        //new Soil_Enthusiast_Home();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PaymentOptionsFrame("Product1, Product2", 100.0, "username");
            }
        });
    }
}
