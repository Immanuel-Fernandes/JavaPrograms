import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TableSetup {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/soil_enthusiast";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    private static final Logger logger = Logger.getLogger(TableSetup.class.getName());

    private static final String CREATE_LOGIN_TABLE_SQL = "CREATE TABLE IF NOT EXISTS login (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), password VARCHAR(255))";

    private static final String CREATE_REGISTER_TABLE_SQL = "CREATE TABLE IF NOT EXISTS register (id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), password VARCHAR(255), email VARCHAR(255), mobileNo INT, Dob DATE, address VARCHAR(255), pincode INT)";

    private static final String CREATE_ORDER_DETAILS_TABLE_SQL = "CREATE TABLE IF NOT EXISTS order_details (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), product_details TEXT, total_amount DOUBLE, payment_mode TEXT, address VARCHAR(255))";

    private static final String CREATE_COMPOST_TABLE_SQL ="CREATE TABLE IF NOT EXISTS CompostCalculated ( id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), length INT, width INT, depth INT, weight DECIMAL(10, 2))";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            createTable(connection, CREATE_LOGIN_TABLE_SQL);
            createTable(connection, CREATE_REGISTER_TABLE_SQL);
            createTable(connection, CREATE_ORDER_DETAILS_TABLE_SQL);
            createTable(connection, CREATE_COMPOST_TABLE_SQL);
            System.out.println("Database tables setup completed successfully.");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Database tables setup error: " + e.getMessage(), e);
        }
    }

    private static void createTable(Connection connection, String createTableSQL) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(createTableSQL)) {
            ps.executeUpdate();
        }
    }
}
