import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Soil_Enthusiast_Home extends JFrame {

    public Soil_Enthusiast_Home() {
        setTitle("Soil Enthusiast");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        ImageIcon welcomeImageIcon = resizeImage("welcome_image.jpg", 65); // Resize to 80% of the original size
        JLabel welcomeLabel = new JLabel(welcomeImageIcon);
        add(welcomeLabel);

        JPanel buttonPanel1 = new JPanel(new GridLayout(1, 2, 20, 20)); // Added horizontal and vertical spacing
        ImageIcon websiteImageIcon = resizeImage("website_image.png", 70); // Resize to 60% of the original size
        ImageIcon websiteVideoIcon = resizeImage("website_video.png", 80); // Resize to 60% of the original size

        JButton websiteButton = new JButton("Website Demo", websiteImageIcon);
        websiteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebpage("https://soil-enthusiast-2024.netlify.app/");
            }
        });

        JButton websiteVideoButton = new JButton("Website Video", websiteVideoIcon);
        websiteVideoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebpage("https://youtu.be/vrqANy-PgS0");
            }
        });

        JPanel buttonPanel2 = new JPanel(new GridLayout(1, 2, 20, 20)); // Added horizontal and vertical spacing
        ImageIcon appImageIcon = resizeImage("app_image.jpg", 70); // Resize to 60% of the original size
        ImageIcon appVideoIcon = resizeImage("app_video.jpg", 70); // Resize to 60% of the original size

        JButton appButton = new JButton("App Demo", appImageIcon);
        appButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebpage("https://youtu.be/j24O1qllG2o"); //CJ App
            }
        });

        JButton appVideoButton = new JButton("App Video", appVideoIcon);
        appVideoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebpage("https://youtu.be/Y3IPMGGflmY"); //Info Video
            }
        });

        buttonPanel1.add(appVideoButton);
        buttonPanel1.add(websiteVideoButton);
        buttonPanel2.add(appButton);
        buttonPanel2.add(websiteButton);

        add(buttonPanel1);
        add(buttonPanel2);

        // Image for the login button
        ImageIcon loginImageIcon = resizeImage("login_image.jpg", 65); // Resize to 60% of the original size
        JButton loginButton = new JButton(loginImageIcon);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SoilEnthusiast();
            }
        });
        add(loginButton);

        // Set window size to 1920x720 pixels
        setSize(1280, 720);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private ImageIcon resizeImage(String imagePath, int percentage) {
        try {
            BufferedImage originalImage = ImageIO.read(getClass().getResource(imagePath));
            int newWidth = (originalImage.getWidth() * percentage) / 100;
            int newHeight = (originalImage.getHeight() * percentage) / 100;
            Image resizedImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            return new ImageIcon(resizedImage);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void openWebpage(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Soil_Enthusiast_Home();
            }
        });
    }
}
